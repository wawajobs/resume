$(function(){
	//获取上边进度条的高度	
	if(true){
		var nowHeight= parseInt($('.one').height()+$('.two').height());
		$('.now').height(nowHeight);
	}
	//第12步、13步的日历
	layui.use('laydate', function(){
		var laydate = layui.laydate;
		var start = {
			min: laydate.now()
			,max: '2099-06-16 23:59:59'
			,istoday: false
			,choose: function(datas){
			end.min = datas; //开始日选好后，重置结束日的最小日期
			end.start = datas //将结束日的初始值设定为开始日
			}
		};
		var end = {
			 min: laydate.now()
			 ,max: '2099-06-16 23:59:59'
			 ,istoday: false
			 ,choose: function(datas){
			  start.max = datas; //结束日选好后，重置开始日的最大日期
			 }
		};

		
		$('#up12').on('click',function(){
			start.elem = this;
	 		laydate(start);
		})
		$('#up13').on('click',function(){
			start.elem = this;
	 		laydate(start);
		})
	})
	
	//第3步的上传文件
	$('#up1').change(function(){
		var filePath=$(this).val();
        var arr=filePath.split('\\');
        var fileName=arr[arr.length-1];
		$('#up1Label').append("&nbsp;&nbsp;&nbsp;"+fileName);
	})
	
	$('#up2').change(function(){
		var filePath=$(this).val();
        var arr=filePath.split('\\');
        var fileName=arr[arr.length-1];
		$('#up2Label').append("&nbsp;&nbsp;&nbsp;"+fileName);
	})
	
	//第13步上传文件
	$('#up13Input').change(function(){
		console.log(1)
		var filePath=$(this).val();
        var arr=filePath.split('\\');
        var fileName=arr[arr.length-1];
		$('#up13label').append("&nbsp;&nbsp;&nbsp;"+fileName);
	})
	
	
})
