$(function(){
	$('.aloneBox').eq(0).css("margin-top","40px")
	
	var nowIndex=0;
	$('#sendIt').on('click',function(){
		nowIndex++;
		var nowcont = $('.tet').val();
		var aloneDiv='<div class="aloneBox" id="'+nowIndex+'"><p class="upRight"><span></span>'+ nowcont+'</p><div style="clear: both;"></div></div>';
		$('.up').append(aloneDiv);
		var nowindex=document.getElementById(nowIndex);
		nowindex.scrollIntoView();
	})
})